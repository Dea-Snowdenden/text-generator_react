export default function isNumber(item) {
  return !!item.match(/[0-9]+/);
}
